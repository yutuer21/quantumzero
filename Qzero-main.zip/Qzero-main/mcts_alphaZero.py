import numpy as np
import copy


def softmax(x):
    probs = np.exp(x - np.max(x))
    probs /= np.sum(probs)
    return probs


class TreeNode(object):

    def __init__(self, parent, prior_p,action):
        self._parent = parent
        self._children = {}  # a map from action to TreeNode
        self._n_visits = 0
        self._Q = 0
        self._u = 0
        self._P = prior_p
        self._prefer=0
        self.ii=action//20     
        
        # add prefer to frequence 0
        if action%20==10:
            self._prefer=0.01
   
        

    def expand(self, action_priors):
        for action, prob in action_priors:
            depth=self.ii+1
            
            if depth*20-1<action<depth*20+20:
                if action not in self._children:
                    self._children[action] = TreeNode(self, prob,action)
                
                          

    def select(self, c_puct):
        return max(self._children.items(),
                   key=lambda act_node: act_node[1].get_value(c_puct))   # calcute each action
    
    

    def update(self, leaf_value):

        # Count visit.
        self._n_visits += 1
        # Update Q, a running average of values for all visits.
        self._Q += 1.0*(leaf_value - self._Q) / self._n_visits
       

    def update_recursive(self, leaf_value):

        # If it is not root, this node's parent should be updated first.
        if self._parent:
            #print("self._parent",self._parent)
            self._parent.update_recursive(leaf_value)       
        self.update(leaf_value)

        
    def get_value(self, c_puct):

        #print("self._prefer",self._prefer)
        self._u = (c_puct * self._P * np.sqrt(self._parent._n_visits) / (1 + self._n_visits))     
        return self._Q + self._u+self._prefer*c_puct

    
    def is_leaf(self):
        return self._children == {}

    def is_root(self):
        return self._parent is None


class MCTS(object):
    """An implementation of Monte Carlo Tree Search."""

    def __init__(self, policy_value_fn, c_puct=5, n_playout=10):

        self._root = TreeNode(None, 1.0,-1)
       
        self._policy = policy_value_fn
        self._c_puct = c_puct
        print(" c_puct", c_puct)
        self._n_playout = n_playout

        
    def _playout(self, state):

        node = self._root

        # select, do_move ~~~~~~~~~
        while(1):
            if node.is_leaf():
                break  
            action, node = node.select(self._c_puct)
            state.do_move(action)                               

          
        # expand node ~~~~~~~~~~
        action_probs, leaf_value = self._policy(state)

        
        # Check for end of game.     
        end, energy,overlap,do= state.game_end()   

        
        if not end:
            node.expand(action_probs)
        else:
            if do == 1: # success
                leaf_value = 10
            else:    
                leaf_value = -1
                
        # update Q-value ~~~~~~~~~~~
        node.update_recursive(leaf_value)
    
    
    

    def get_move_probs(self, state, temp=1e-3):
        # temp: temperature parameter in (0, 1] controls the level of exploration
       
        for n in range(self._n_playout):
            
            state_copy = copy.deepcopy(state)
            self._playout(state_copy)

        # calc the move probabilities based on visit counts at the root node
        act_visits = [(act, node._n_visits) for act, node in self._root._children.items()]
        acts, visits = zip(*act_visits)

        act_probs = softmax(1.0/temp * np.log(np.array(visits) + 1e-10))

        return acts, act_probs
    
    
    

    def update_with_move(self, last_move):
        """Step forward in the tree, keeping everything we already know
        about the subtree.
        """
        if last_move in self._root._children:
            self._root = self._root._children[last_move]
            self._root._parent = None
        else:
            self._root = TreeNode(None, 1.0,last_move)

    def __str__(self):
        return "MCTS"


class MCTSPlayer(object):
    """AI player based on MCTS"""

    def __init__(self, policy_value_function,
                 c_puct=5, n_playout=2000, is_selfplay=1):
        self.mcts = MCTS(policy_value_function, c_puct, n_playout)
        self._is_selfplay = is_selfplay

    def set_player_ind(self, p):
        self.player = p

    def reset_player(self):
        self.mcts.update_with_move(-1)

    def get_action(self, board, temp=1e-3, return_prob=1):
        sensible_moves = board.availables
        move_probs = np.zeros(board.width*board.height)
        
        if len(sensible_moves) > 0:
            acts, probs = self.mcts.get_move_probs(board, temp)
     

            if self._is_selfplay:
                p1=0.7*probs + 0.3*np.random.dirichlet(0.3*np.ones(len(probs)))
                move_probs[list(acts)] = p1
                move = np.random.choice(acts,p=p1)
                #pp=p1.tolist()
                #ii=pp.index(max(pp))
                #move=acts[ii]
                self.mcts.update_with_move(move)
 
            else:
                p1=probs
                move_probs[list(acts)] = p1
                move = np.random.choice(acts, p=p1)
                #pp=p1.tolist()
                #ii=pp.index(max(pp))
                #move=acts[ii]
                self.mcts.update_with_move(move)
                
            if return_prob:
                return move, move_probs
            else:
                return move
        else:
            print("WARNING: the board is full")   

    def __str__(self):
        return "MCTS {}".format(self.player)
