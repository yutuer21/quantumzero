from __future__ import print_function
import numpy as np
from satmethod import system,method
from dynamics import SatSearchEfficient
import matplotlib.pyplot as plt
from numpy import *
from scipy import linalg
import math

global exmove
global exenergy
global exsimilar

exmove=[]
exenergy=[]
exsimilar=[]

class Board(object):
    """board 
        for the game"""

    def __init__(self,ini,T,Nqubit, result,Hi,**kwargs):
        self.width = int(kwargs.get('width', 8))    #### 
        self.height = int(kwargs.get('height', 8))
        self.Mheight=int(kwargs.get('Mheight', 8))  
        self.Nwidth=int(kwargs.get('Nwidth', 8)) 
        #self.nbit=self.width
        #self.nmodular=self.height 
        #print ("nbit",self.nbit)
        #print("nmodular",self.nmodular)
        
        if ini==1:       
            global exmove
            global exenergy
            global exsimilar
            
            exmove=[]
            exenergy=[]
            exsimilar=[]
              
       
        self.De=self.width  #20
        self.Cut=self.height #5                   ## frequence cut
        
        
        self.T=T
        self.nqubit=Nqubit
        print("nquibit", self.nqubit,"T",T)
     
        
     
        n_qubit=self.nqubit  
        HB,HP=system.satSystem(n_qubit,result)
        print("HP",HP)
        self.HB=HB
        self.HP=HP
        self.Hi=Hi      # Hamiltonian information
        
        

        self.states = {}
        self.players = [1]  
        
      
    

    def init_board(self, start_player=0):
        self.current_player = self.players[start_player]  # start player
        self.availables = list(range( self.height*self.width))
        self.states = {}
        self.last_move = -1

    def move_to_location(self, move):
        """
        3*3 board's moves like:
        6 7 8
        3 4 5
        0 1 2
        and move 5's location is (1,2)
        """
        h = move // self.width
        w = move % self.width
        return [h, w]

    def location_to_move(self, location):
        if len(location) != 2:
            return -1
        h = location[0]
        w = location[1]
        move = h * self.width + w
        if move not in range( self.height*self.width ):
            return -1
        return move

    def current_state(self):
        """return the board state from the perspective of the current player.
        state shape: 4*width*height
        """

        square_state = np.zeros((1, self.height,self.width))
        if self.states:
            moves, players = np.array(list(zip(*self.states.items())))
            move_curr = moves[players == self.current_player]
            square_state[0][move_curr // self.width,move_curr % self.width] = 1.0
                        
        square_state1 =np.reshape(square_state[:, ::-1, :],(self.height*self.width))
        
        # state+Hamiltonian information
        state=square_state1.tolist()+self.Hi
     
        return np.array(state)
    
    
    def do_move(self, move):
        self.states[move] = self.current_player
        self.availables.remove(move)
        self.last_move = move

    def has_a_winner(self):
        width = self.width
        height = self.height
        states = self.states
         
        
        moved = list(set(range(width * height)) - set(self.availables))       
        movelist=sorted(moved)
        #print("movelist",movelist)
        
        global exmove
        global exenergy
        global exsimilar

        self.obs=np.zeros((1, self.Cut), dtype=np.float64)
        for m in movelist:
            self.obs[0,m//self.De]=-0.2+m%self.De*0.02

        obs=self.obs[0]

        
        if movelist in exmove:
            sit=exmove.index(movelist)
            self.genergy=exenergy[sit]
            self.over_lap=exsimilar[sit]

        else:        
            pathdesign=SatSearchEfficient(self.nqubit,self.T,self.Cut,self.HB,self.HP)
            energy,fidelity =  pathdesign.evolution(obs)

            
            self.genergy=energy
            self.over_lap=fidelity

            
            exmove.append(movelist)
            exenergy.append(self.genergy)
            exsimilar.append(self.over_lap)
            
        
        
        
#success    
        if self.genergy<0.01:    
            print("movelist-end",movelist,"win")
            print("obs:",obs)
            return True, real(self.genergy),self.over_lap,1                      
#fail
        if len(movelist)==self.Cut:  
            print("movelist-end",movelist,"fail")
            print("obs:",obs)
            return True, real(self.genergy),self.over_lap,0

        
        return False,1,1,-1
                

    def game_end(self):
        """Check whether the game is ended or not"""
        win,energy,overlap,do = self.has_a_winner()
        if win:
            return True,energy,overlap,do        
        return False, 1,1,-1
    
    def game_end2(self):
        width = self.width
        height = self.height
        states = self.states
         
        moved = list(set(range(width * height)) - set(self.availables))       
   
        
        if len(moved)<5:
            #print("mid-sim:", "False")
            return False, 1,1,-1       #end, energy,overlap,do

        if len(moved)==5:
            win,energy,overlap,do = self.has_a_winner()
            #print("end-sim:", win)
            return True,energy,overlap,do     #end, energy,overlap,do （1，0）
       
        
        
        
        

    def get_current_player(self):
        return self.current_player


    def endpp(self):
        global exmove
        global exenergy
        global exsimilar
        energy=min(exenergy)
        sit=exenergy.index(energy)
        over_lap=exsimilar[sit]
        movelist=exmove[sit]
        print ("movelist",movelist)
        obs=np.zeros((1, self.Cut), dtype=np.float64)
        for m in movelist:
            obs[0,m//self.De]=-1+m%self.De*0.1
        print(obs)
        
        a, bb = np.linalg.eig(self.HB)
        idx = a.argsort()[::1]   
        a = a[idx]
        bb = bb[:,idx]    
        
        a, bp = np.linalg.eig(self.HP)
        idx = a.argsort()[::1]   
        a = a[idx]
        bp = bp[:,idx]
        
        ax=[]
        ay=[]
        ay2=[]
        ac=[]
        ae=[]
        plt.ion() 
        wf=bb[:,0]
        for t in range(1,self.T+1):
            ax.append(t)
            st=t/self.T
            for i in range(1,self.Cut+1):
                st=st+obs[0,i-1]* math.sin(i*3.1415*t/self.T)
            H=(1-st)*self.HB+st*self.HP
            Bt=linalg.expm(-1j*np.asarray(H))
            wf=np.matmul(Bt, wf)
            
            
            c=np.dot(bp[:,0].conjugate().T,wf)    ####overlap
            c1=abs(c)**2
            ac.append(c1)
            
            ee=np.dot(self.HP,wf)
            ee=np.dot(wf.conjugate().T,ee)     ##ground energy
            ae.append(ee)
        
        plt.clf()             
        plt.plot(ax,ac)
        plt.plot(ax,ae)
        plt.ioff()  
















class Game(object):
    """game server"""

    def __init__(self, board, **kwargs):
        self.board = board

    def graphic(self, board, player1):
        """Draw the board and show game info"""
        width = board.width
        height = board.height

        print("Player", "with X".rjust(3))
       
        print()
        for x in range(width):
            print("{0:8}".format(x), end='')
        print('\r\n')
        for i in range(height - 1, -1, -1):
            print("{0:4d}".format(i), end='')
            for j in range(width):
                loc = i * width + j
                p = board.states.get(loc, -1)
                if p == 1:
                    print('X'.center(8), end='')
                else:
                    print('-'.center(8), end='')
            print('\r\n\r\n')




    def start_self_play(self, player, is_shown=0, temp=1e-3):
        """ start a self-play game using a MCTS player, reuse the search tree,
        and store the self-play data: (state, mcts_probs, z) for training
        """
        self.board.init_board()
        p1= self.board.players
        states, mcts_probs, current_players = [], [], []
        while True:
          
            move, move_probs = player.get_action(self.board,
                                                temp=temp,
                                                 return_prob=1)
            print("move",move)
            
            # store the data
            states.append(self.board.current_state())
            mcts_probs.append(move_probs)
            current_players.append(self.board.current_player)

            # perform a move
            self.board.do_move(move)
            if is_shown:
                self.graphic(self.board, p1)
                
            end,energy,overlap,do = self.board.game_end()       
            winner=1
            if end:
                winners_z = np.zeros(len(current_players)) 
             
        
                if do==1:
                    print("Game end. find eigenstate:", energy, overlap)
                    winners_z[np.array(current_players) == winner] =10     #np.tanh(0.01/energy)   #-np.tanh(energy)
                        
                else:
                    print("Game end. Fail")
                    winners_z[np.array(current_players) == winner] = -1
                print("winners_z",winners_z)
                
               
                # reset MCTS root node
                player.reset_player()
                #print("state:",states)
                #print("mcts_probs:",mcts_probs)
                return winner, zip(states, mcts_probs, winners_z),energy,overlap
            
            

    def endp(self):
        self.board.endpp()



