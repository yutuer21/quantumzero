# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 14:45:51 2020

@author: yuqinchen
"""
from __future__ import print_function
import random
import numpy as np
from collections import defaultdict, deque
from policy_value_net_tensorflow import PolicyValueNet 
import matplotlib.pyplot as plt
import time
import math
from numpy import *
from scipy import linalg
from satmethod import system,method


class pretraind():
    
    def pretraindata(fgood,finfo):
        
        def astate(i,obs):
            current_state=np.zeros([5,20])
            for j in range(i):  
                sit=int((obs[j]+0.2)*100)
                current_state[4-j,int(sit/2)]=1
            return current_state
        
        
        def totalstate(obs):    
            state=[]
            for i in range(5):
                current_state1=astate(i,obs)
                #print(obs,current_state1)
                current_state1=np.reshape(current_state1,(1,5,20))
                state.append(current_state1)   
            return state
            
        
        def totalprobs(obs):
            tpro=[]
            for i in range(5):
                probs=[0]*(5*20)
                sit=int((obs[i]+0.2)*100)
                sitt=i*20+int(sit/2)
                probs[sitt]=1     
                tpro.append(probs)
            return tpro
            
        def totalvalue(obs):
            value=[1.]*5
            return value
            
            

        
        def collectdata(sat4obs):
            state_batch=[]
            mcts_probs_batch=[]
            winner_batch=[]
            for index, obs in enumerate(sat4obs):
                
                sitf=[]
                for f in range(5):  
                    sit=int((obs[f]+0.2)*100)
                    sitf.append(sit/2)
                if max(sitf)<20:   #tiao guole daoda shangxian 0.2de lizi
                    state=totalstate(obs)
                    tpro=totalprobs(obs)
                    value=totalvalue(obs)
                    #print("state",state.shape)
                    state_batch=state_batch+state
                    
                    #state_batch1=state_batch1+state1
                    mcts_probs_batch= mcts_probs_batch+tpro
                    winner_batch=winner_batch+value
                
            return state_batch,mcts_probs_batch, winner_batch
        
        
        
        
        # params of the board and the game
        board_width = 20      #N-qubit    divide
        board_height = 5    # N-modular     frequency
        
        learn_rate= 2e-3
        lr_multiplier= 1.0
        epochs=200
        
        #data collection
        sat4obs1=np.loadtxt(fgood)
        sat4obs=sat4obs1.tolist()
        data_size=len(sat4obs)
        
        state_batch,mcts_probs_batch, winner_batch=collectdata(sat4obs)  ##收集的好的obs
        
        #print(data_size)
        #print(sat4obs[1])
        #print(state_batch[9])
        #print(state_batch[9].shape)
        #print(len(state_batch))
        
        state_batch1=state_batch
        for i in range(len(state_batch)):
            state_batch1[i]=np.reshape(state_batch[i],(20*5)) 
            
        #print(state_batch1[9])
        #print(state_batch1[9].shape)
        #print(len(state_batch1))
            
        
        
        hh=np.loadtxt(finfo)
        Hinfo=hh.tolist()
        print("Hinfo",len(Hinfo))
        
        
        state_batch2=state_batch1
        for i in range(len(state_batch)):
            #print("LLL1:",len(state_batch1[i]))
            state_batch2[i]=state_batch1[i].tolist()+Hinfo[int(i/5)]
            #print("LLL2:",Hinfo[int(i/5)],state_batch2[i])
            
        print("totoalinput_dim",len(state_batch2[4]))
                
        
        return state_batch2,mcts_probs_batch,winner_batch
        
  


      
    



