# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 14:46:36 2019

@author: yuqinchen
"""
from dynamics import SatSearchEfficient
import mdts
import math
from numpy import *
from scipy import linalg
import numpy as np
import matplotlib.pyplot as plt
import random

class system():
    
    def satSystem(n_qubit,result):
        N=2**n_qubit
    
    
        sx=np.array([[0,1],[1,0]])
        si=np.array([[1,0],[0,1]])
    
        HB=np.kron(si,si)
        for i in range(n_qubit-2):
            HB=np.kron(si,HB)
        HB=n_qubit*HB/2
    
        for j in range(n_qubit):
            if j==0:
                B=sx
                for i in range(n_qubit-1-j):
                    B=np.kron(si,B) 
            else:    
                for i in range(j):
                    if i==0:
                        B=si 
                    else: 
                        B=np.kron(si,B)  
                B=np.kron(sx,B)   
                for i in range(n_qubit-1-j):
                    B=np.kron(si,B)
    
            HB=HB-B/2
    
    
    
        
        HC= np.zeros((N,N))
        for i in result:
            HC[i,i]=HC[i,i]+1
        HP=HC
        
        return HB,HP
    


class method():
    
    
    def linear(n_qubit,T,Mcut,HB,HP):
        pathdesign=SatSearchEfficient(n_qubit,T,Mcut,HB,HP)   
    
        obs=np.array([0.,0., 0.,0., 0.])
        energy,fidelity =  pathdesign.evolution(obs)
        return fidelity
    
   
    def StochasticDescent(n_qubit,T,Mcut,HB,HP):
        pathdesign=SatSearchEfficient(n_qubit,T,Mcut,HB,HP)
        
        delta=0.02#/4
        iterNum=100
        ncan=0
        obs=np.random.rand(Mcut)*0.   #0.02
        list = [x/100  for x in range(-20, 20,2)]
       

        for i in range (Mcut):
        #  #  obs[i]=random.uniform(-0.2,0.2)
            slice = random.sample(list, 1) 
            obs[i]=slice[0]
        print(obs)
        
        iter = 0
        while True:
            iter += 1
            
            energy,fidelity = pathdesign.evolution(obs)
            ncan=ncan+1
            obs1=obs
            fid=fidelity
            num_converge = 0
            for m in range(1, 1+Mcut):
                #print('Updating parameter b{}'.format(m))
                if  obs[m-1]+ delta > 0.2 or obs[m-1] - delta < -0.2:
                    num_converge += 1
                    continue
                obs[m-1] += delta #/m    #高频的变化幅度大于低频
                #print(delta/m )
                #print(obs)
                energy,fidelity =  pathdesign.evolution(obs)
                ncan=ncan+1
                if fidelity > fid:
                    fid=fidelity
                    #print('b{}+delta'.format(m))
                    continue 
                else:
                    obs[m-1] -= 2*delta #/m    #把加的减回去-1
                    #print(delta/m )
                    #print(obs)
                    energy,fidelity =  pathdesign.evolution(obs)        ##调用前面的函数
                    ncan=ncan+1
                    if fidelity > fid:
                        fid=fidelity
                        #print('b{}-delta'.format(m))
                        continue 
                    else:
                        obs[m-1] += delta #/m
                        num_converge += 1  #（改变每一个b，结果都不变了）
                        #print('keep invariant')  
                        continue 
            if num_converge == Mcut:
                #print('fidelity:', fid,energy)
                break
            if iter > iterNum:
                print('WARNING: The algorithm does not converge')
                break 
        #print(iter)
        print(iter,ncan)
        return obs1, fid
    
    
    
    
    
    

    def mcts(n_qubit,T,Mcut,HB,HP,ncandidates):
        
        pathdesign=SatSearchEfficient(n_qubit,T,Mcut,HB,HP)
        
        def get_reward(struct):
            delta=0.1             ##update lenth
            De=20  #20
            #print("De",De)
            Mcut=5 #5                   ## frequence cut
        
            obs=np.zeros((Mcut), dtype=np.float64)   
            for i in range(Mcut):
                obs[i]=-0.2+struct[i]%De*0.02
                
            energy,fidelity = pathdesign.evolution(obs)    
            cond=fidelity   #增强能量的效果
        
            return cond
        
        myTree=mdts.Tree(T,no_positions=5, atom_types=list(range(20)), atom_const=None, get_reward=get_reward, positions_order=list(range(5)),
                max_flag=True,expand_children=10, play_out=5, play_out_selection="best", space=None, candidate_pool_size=100,
                 ucb="mean", use_combo=False, combo_play_out=20, combo_init_random=5, combo_step=5, combo_lvl=5)
        
        res=myTree.search(display=True,no_candidates=ncandidates)

        print (res.checked_candidates_size/50)
        fidelity=res.optimal_fx  
        obs=res.optimal_candidate 
        
        return obs,fidelity