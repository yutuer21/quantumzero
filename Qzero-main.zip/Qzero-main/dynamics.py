import numpy as np 
from qutip import * 
from numpy import *



class SatSearchEfficient():
    def __init__(self, n_qubit, T, Mcut,HB,HP):
        self.n_qubit = n_qubit
        self.N = 2**self.n_qubit
        self.T = T 
        self.Mcut = Mcut

       
        
        a, bb = np.linalg.eig(HB)
        idx = a.argsort()[::1]   
        a = a[idx]
        bb = bb[:,idx]  
        
        a, bp = np.linalg.eig(HP)
        idx = a.argsort()[::1]   
        a = a[idx]
        bp = bp[:,idx]

        self.H1=Qobj(HB)
        self.H2=Qobj(HP)
        
        self.psi0 =Qobj(bb[:,0])
        self.psif =Qobj(bp[:,0])
      

    def H1_coef(self, t, args):
        s = t/self.T 
        j = 1
        for b in args:
            s += args[b] * np.sin(j*np.pi*t/self.T)
            j += 1
        return 1-s

    def H2_coef(self, t, args):
        s = t/self.T 
        j = 1
        for b in args:
            s += args[b] * np.sin(j*np.pi*t/self.T)
            j += 1
        return s

    def evolution(self, bstate):
        args = {}
        for i, b in enumerate(list(bstate)):
            args['b{}'.format(i+1)] = b 
            
            
        dt=0.5
        NL=self.T/dt
    
         
        
        t = np.linspace(dt, self.T-dt, int(NL))
        H = [[self.H1, self.H1_coef], [self.H2, self.H2_coef]]
        output = mesolve(H, self.psi0, t, args=args)

        
        states = output.states[-1]
        
        c= (self.psif.dag()) * states    ####overlap
        fidelity=np.abs(c[0,0])**2
       
        x=states.dag()*self.H2*states      ###energy
        energy=x[0,0]
        
    
        return energy, fidelity



